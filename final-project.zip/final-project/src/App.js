
import './App.css';
import Router from './Pages/Router';


function App() {
  return (
    <div className="App" >
      <Router/>
    </div>
  );
}

export default App;
